package controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import data.EventDAO;
import data.PaymentDAO;
import model.EventErrorMsgs;
import model.EventModel;
import model.PaymentModel;

/**
 * Servlet implementation class EventController
 */
@WebServlet("/EventController")
public class EventController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EventController() {
		super();
		// TODO Auto-generated constructor stub
	}

	private EventModel getEventParam(HttpServletRequest request) {
		return new EventModel(request.getParameter("eventId"), request.getParameter("date"),
				request.getParameter("event_name"), request.getParameter("start_time"),
				request.getParameter("duration"), request.getParameter("Hall_Name"),
				request.getParameter("est_attendees"), request.getParameter("Food_Type"),
				request.getParameter("Meal_Type"), request.getParameter("Drink_Type"),
				request.getParameter("entertainment"), request.getParameter("Meal_Formality"),
				request.getParameter("staffFirstName"), request.getParameter("staffLastName"),
				request.getParameter("event_status"), request.getParameter("price"));
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		String userName = request.getParameter("userName");
		System.out.println("INFO: EventController.doPost action is: line 65" + action);
		if (action.equalsIgnoreCase("add")) {
			EventModel eventmodel = getEventParam(request);
			EventErrorMsgs eventErrors = new EventErrorMsgs();
			eventmodel.validateAttendees(eventErrors);
			eventmodel.validateDuration(eventErrors);
			eventmodel.validateEvenName(eventErrors);
			eventmodel.validateHall(eventErrors);
			eventErrors.setStaffFirstNameError("");
			eventErrors.setStaffLastNameError("");
			try {
				eventmodel.validateDate(userName, eventErrors);
			} catch (ParseException e) {
			}
			if (eventErrors.getErrorMsg() == null) {
				session.removeAttribute("EventErrorMsgs");
				int eventID = EventDAO.AddEvent(userName, eventmodel.getLastName(), eventmodel.getFirstName(),
						eventmodel.getDate(), eventmodel.getName(), eventmodel.getStartTime(), eventmodel.getDuration(),
						eventmodel.getHallName(), eventmodel.getAttendees(), eventmodel.getFoodType(),
						eventmodel.getMeal(), eventmodel.getDrinkType(), eventmodel.getEntertainmentItems(),
						eventmodel.getFormal());
				PaymentModel paymentModel = PaymentDAO.generatePayment(eventID, userName);
				session.setAttribute("PaymentModel", paymentModel);
				getServletContext().getRequestDispatcher("/Payment.jsp").forward(request, response);
			} else {
				System.out.println("INFO: EventController.doPost line 89: error in fields");
				DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
				DateFormat tf = new SimpleDateFormat("hh:mm aa");
				Date dateobj = new Date();
				session.setAttribute("currdate", df.format(dateobj));
				session.setAttribute("currtime", tf.format(dateobj));
				session.setAttribute("EventModel", eventmodel);
				session.setAttribute("EventErrorMsgs", eventErrors);
				getServletContext().getRequestDispatcher("/RequestEvent.jsp").forward(request, response);
			}
		}

		else if (action.equalsIgnoreCase("viewEvent")) {
			String date = request.getParameter("date");
			String time = request.getParameter("start_time");
			ArrayList<EventModel> eventSummary = EventDAO.viewEvent(userName, date, time);
			session.setAttribute("EventModelList", eventSummary);
			getServletContext().getRequestDispatcher("/EventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("viewEventM")) {
			String date = request.getParameter("date");
			String time = request.getParameter("start_time");
			ArrayList<EventModel> eventSummary = EventDAO.viewEvent(userName, date, time);
			session.setAttribute("EventModelList", eventSummary);
			getServletContext().getRequestDispatcher("/ManagerEventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("viewEventS")) {
			String date = request.getParameter("date");
			String time = request.getParameter("start_time");
			ArrayList<EventModel> eventSummary = EventDAO.viewEvent(userName, date, time);
			session.setAttribute("EventModelList", eventSummary);
			getServletContext().getRequestDispatcher("/StaffEventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("viewSelectedEvent")) {
			String id = request.getParameter("id");
			EventModel eventmodel = EventDAO.viewSelectedEvent(id);
			System.out.println("INFO: EventController.doPost line 123:" + eventmodel.getFormal());
			session.setAttribute("EventModel", eventmodel);
			getServletContext().getRequestDispatcher("/ViewEventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("viewSelectedEventM")) {
			String id = request.getParameter("id");
			EventModel eventmodel = EventDAO.viewSelectedEvent(id);
			System.out.println("INFO: EventController.doPost line 131:" + eventmodel.getFormal());
			session.setAttribute("EventModel", eventmodel);
			getServletContext().getRequestDispatcher("/MgrViewEventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("viewSelectedEventS")) {
			String id = request.getParameter("id");
			EventModel eventmodel = EventDAO.viewSelectedEvent(id);
			System.out.println("INFO: EventController.doPost line 139:" + eventmodel.getFormal());
			session.setAttribute("EventModel", eventmodel);
			getServletContext().getRequestDispatcher("/StaffViewEventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("cancel")) {
			String eventID = request.getParameter("eventId");
			EventDAO.cancelEvent(eventID);
			session.setAttribute("userName", userName);
			session.removeAttribute("EventModel");
			getServletContext().getRequestDispatcher("/ViewEventSummary.jsp").forward(request, response);
		}

		else if (action.equalsIgnoreCase("modify")) {
			String eventID = request.getParameter("eventId");
			EventModel eventModel = getEventParam(request);
			EventErrorMsgs eventErrors = new EventErrorMsgs();
			// eventErrors.setFirstNameError("");
			eventModel.validateAttendees(eventErrors);
			eventModel.validateDuration(eventErrors);
			eventModel.validateHall(eventErrors);
			// eventErrors.setEventNameError("");
//			eventErrors.setLastNameError("");
//			eventErrors.setStaffFirstNameError("");
//			eventErrors.setStaffLastNameError("");
//			eventErrors.setUserNameError("");
			try {
				eventModel.validateDate(request.getParameter("userName"), eventErrors);
			} catch (ParseException e) {
			}
			if (eventErrors.getErrorMsg() == null) {
				EventDAO.modifyEvent(eventModel, eventID);
				EventModel newEventModel = EventDAO.viewSelectedEvent(eventID);
				session.removeAttribute("EventErrorMsgs");
				session.setAttribute("EventModel", newEventModel);
				getServletContext().getRequestDispatcher("/ViewEventSummary.jsp").forward(request, response);
			} else {
				session.setAttribute("EventErrorMsgs", eventErrors);
				getServletContext().getRequestDispatcher("/ViewEventSummary.jsp").forward(request, response);

			}
		} else if (action.equalsIgnoreCase("change"))

		{
			String eventID = request.getParameter("eventId");
			EventModel eventModel = getEventParam(request);
			EventErrorMsgs eventErrors = new EventErrorMsgs();
			eventModel.validateAttendees(eventErrors);
			eventModel.validateDuration(eventErrors);
			eventModel.validateHall(eventErrors);
			eventErrors.setEventNameError("");
			eventErrors.setStaffFirstNameError("");
			eventErrors.setStaffLastNameError("");
			try {
				eventModel.validateDate(request.getParameter("userName"), eventErrors);
			} catch (ParseException e) {
			}

			if (eventErrors.getErrorMsg() == null) {
				EventDAO.modifyEvent(eventModel, eventID);
				EventModel newEventModel = EventDAO.viewSelectedEvent(eventID);
				session.setAttribute("EventModel", newEventModel);
				session.removeAttribute("EventErrorMsgs");
				getServletContext().getRequestDispatcher("/MgrViewEventSummary.jsp").forward(request, response);
			} else {
				session.setAttribute("EventErrorMsgs", eventErrors);
				getServletContext().getRequestDispatcher("/MgrViewEventSummary.jsp").forward(request, response);
			}
		}

		else if (action.equalsIgnoreCase("assign")) {
			String eventID = request.getParameter("eventId");
			EventModel eventModel = getEventParam(request);
			EventErrorMsgs eventErrors = new EventErrorMsgs();
//			eventErrors.setFirstNameError("");
//			eventErrors.setAttendeesError("");
//			eventErrors.setDurationError("");
//			eventErrors.setEventNameError("");
//			eventErrors.setHallError("");
//			eventErrors.setLastNameError("");
//			eventErrors.setUserNameError("");

			eventModel.validateStaffExists(eventErrors);
			eventModel.validateStaffExists(eventErrors);
			if (eventErrors.getErrorMsg() != null) {
				System.out.println("INFO: EventController.doPost line 185: Error updating event");
				session.setAttribute("EventErrorMsgs", eventErrors);
				getServletContext().getRequestDispatcher("/MgrViewEventSummary.jsp").forward(request, response);
			} else {
				EventDAO.assign(eventID, eventModel.getStaffFirstName(), eventModel.getStaffLastName());
				EventModel newEventModel = EventDAO.viewSelectedEvent(eventID);
				session.setAttribute("EventModel", newEventModel);
				session.removeAttribute("EventErrorMsgs");
				getServletContext().getRequestDispatcher("/MgrViewEventSummary.jsp").forward(request, response);
			}
		} else if (action.equalsIgnoreCase("pay")) {

		}

	}

}
